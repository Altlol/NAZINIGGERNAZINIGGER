_G.ToggleKeyBind = "g"
loadstring(game:HttpGet('https://cattori.xyz/main.lua'))()
