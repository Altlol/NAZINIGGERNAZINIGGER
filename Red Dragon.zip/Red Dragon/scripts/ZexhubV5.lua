--// Zex hub V5 UnSecured & Official Scipt

loadstring(game:HttpGet("https://raw.githubusercontent.com/Remot3r/ZexScripts/master/ZexHubV5b.txt"))()