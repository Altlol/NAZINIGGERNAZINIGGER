--[[----------------------------------------------------------------
|                ▄▀▄▄▄▄   ▄▀▀▄ ▄▀▄  ▄▀▀█▄▄   ▄▀▀▄  ▄▀▄             |
|               █ █    ▌ █  █ ▀  █ █ ▄▀   █ █    █   █             |
|              ▐ █      ▐  █    █ ▐ █    █ ▐     ▀▄▀               |
|                █        █    █    █    █      ▄▀ █               |
|               ▄▀▄▄▄▄▀ ▄▀   ▄▀    ▄▀▄▄▄▄▀     █  ▄▀               |
|              █     ▐  █    █    █     ▐    ▄▀  ▄▀                |
|              ▐        ▐    ▐    ▐         █    ▐                 |
|               ▐        ▐    ▐    ▐         █    ▐                |
|------------------------------------------------------------------|
|    Credits:    | Binds & Info:                                   |
|    pigeon#8951 | U                         Open and close output |
|      fini#7057 | RShift                          Fill suggestion |
|     adam᲼#2002 | ;                               Focus on CMDBar |
| -------------- | Q                                Open and close |
|                | LShift+Bksp                        Clear CMDbar |
|                |                                                 |
|                | .cmds                             List commands |
----------------------------------------------------------------]]--
loadstring(game:HttpGet("https://raw.githubusercontent.com/CMD-X/CMD-X/master/Source", true))()
