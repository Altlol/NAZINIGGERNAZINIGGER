emptystack
getglobal game
getfield Workspace
getfield LocalPlayer
getfield Remove
pushvalue 11
setfield Noclip
pcall 2 1 0
emptystack
